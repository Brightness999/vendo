import Landing from '../components/Landing'

export default function Home() {
  return (
    <Landing />
  )
}
